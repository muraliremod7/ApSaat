package com.pronix.android.apssaataudit.common;

/**
 * Created by ravi on 1/2/2018.
 */

public class SqliteConstants {

    public static String TABLE_USERMASTER = "UserMaster";
    public static String TABLE_FORMAT4A = "employees";
}


