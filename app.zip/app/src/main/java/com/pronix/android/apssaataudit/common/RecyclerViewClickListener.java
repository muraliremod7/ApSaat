package com.pronix.android.apssaataudit.common;

import android.view.View;

/**
 * Created by ravi on 2/23/2018.
 */

public interface RecyclerViewClickListener {
    public void onItemClick(View v, int position);
}

