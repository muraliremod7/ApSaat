package com.pronix.android.apssaataudit.pojo;

/**
 * Created by ravi on 2/23/2018.
 */

public class Habitations {

    private String habitationCode;
    private String habitationName;
    private String mandalCode;
    private String districtCode;

    public String getHabitationCode() {
        return habitationCode;
    }

    public void setHabitationCode(String habitationCode) {
        this.habitationCode = habitationCode;
    }

    public String getHabitationName() {
        return habitationName;
    }

    public void setHabitationName(String habitationName) {
        this.habitationName = habitationName;
    }

    public String getMandalCode() {
        return mandalCode;
    }

    public void setMandalCode(String mandalCode) {
        this.mandalCode = mandalCode;
    }

    public String getDistrictCode() {
        return districtCode;
    }

    public void setDistrictCode(String districtCode) {
        this.districtCode = districtCode;
    }
}
