package com.pronix.android.apssaataudit.models;

/**
 * Created by ravi on 1/3/2018.
 */

public class UserMasterDO {

    public void  UserMasterDO()
    {

    }

    public  String userId = "";
    public String userName = "";
    public String mobileNumber = "";
    public String email = "";
    public String designation = "";
}
