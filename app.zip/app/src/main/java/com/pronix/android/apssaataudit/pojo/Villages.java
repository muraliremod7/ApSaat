package com.pronix.android.apssaataudit.pojo;

/**
 * Created by ravi on 2/23/2018.
 */

public class Villages {

    private String villageCode;
    private String villageName;

    public String getVillageCode() {
        return villageCode;
    }

    public void setVillageCode(String villageCode) {
        this.villageCode = villageCode;
    }

    public String getVillageName() {
        return villageName;
    }

    public void setVillageName(String villageName) {
        this.villageName = villageName;
    }
}
