package com.pronix.android.apssaataudit.services;

import com.pronix.android.apssaataudit.models.WebServiceDO;

/**
 * Created by ravi on 1/11/2018.
 */

public interface OnTaskCompleted {

    void onTaskCompletes(WebServiceDO webServiceDO);
  }
