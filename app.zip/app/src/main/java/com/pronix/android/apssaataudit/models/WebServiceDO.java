package com.pronix.android.apssaataudit.models;

/**
 * Created by ravi on 1/10/2018.
 */

public class WebServiceDO {

    public String responseContent;
    public String responseCode;
    public String result;
    public String request;
}
